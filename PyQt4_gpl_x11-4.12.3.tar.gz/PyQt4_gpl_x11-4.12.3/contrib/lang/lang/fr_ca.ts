<!DOCTYPE TS><TS>
<context>
    <name>MainWindow</name>
    <message>
        <source>Title</source>
        <translation type="unfinished">Titre</translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="unfinished">Texte</translation>
    </message>
    <message>
        <source>Language</source>
        <translation type="unfinished">Langue</translation>
    </message>
</context>
</TS>
