<!DOCTYPE TS><TS>
<context>
    <name>MainWindow</name>
    <message>
        <source>Title</source>
        <translation type="unfinished">Titel</translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="unfinished">Tekst</translation>
    </message>
    <message>
        <source>Language</source>
        <translation type="unfinished">Sprog</translation>
    </message>
</context>
</TS>
